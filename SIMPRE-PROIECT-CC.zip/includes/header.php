<div class="header" id="home">
      <div class="content white agile-info">
         <nav class="navbar navbar-default" role="navigation">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
            </button>
                  <a class="navbar-brand" href="index.html">
                     <h1><span class="fa fa-signal" aria-hidden="true"></span> WORK MANAGEMENT APP <label>NEXTLAB.TECH</label></h1>
                  </a>
               </div>
               <!--/.navbar-header-->
               <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <nav class="link-effect-2" id="link-effect-2">
                     <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php" class="effect-3">Work</a></li>
                        <li><a href="employee/login.php" class="effect-3">Angajat</a></li>
                        <li><a href="admin/login.php" class="effect-3">Admin</a></li>
                     </ul>
                  </nav>
               </div>
               <!--/.navbar-collapse-->
               <!--/.navbar-->
            </div>
         </nav>
      </div>
   </div>