
   <div class="footer_w3ls">
      <div class="container">
         <div class="footer_bottom">
            <div class="col-md-9 footer_bottom_grid">
               <div class="footer_bottom1">
                  <a href="index.html">
                     <h2><span class="fa fa-signal" aria-hidden="true"></span> WORK MANAGEMENT APP <label>NEXTLAB.TECH</label></h2>
                  </a>
                  <p>Autor: Sergiu Costan @ 2024</p>
               </div>
            </div>
            <div class="col-md-3 footer_bottom_grid">
               <h6>Follow Us</h6>
               <div class="social">
                  <ul>
                     <li><a href="https://www.facebook.com/nextlab.tech.education"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="https://www.instagram.com/nextlab.tech/"><i class="fa fa-instagram"></i></a></li>
                     <li><a href="https://www.youtube.com/@NEXTLABTECH"><i class="fa fa-youtube"></i></a></li>
                     <li><a href="https://www.linkedin.com/company/nextlabtech"><i class="fa fa-linkedin"></i></a></li>
                     <li><a href="https://discord.com/invite/nextlab"><i class="fa-brands fa-discord"></i></a></li>
                  </ul>
               </div>
            </div>
            <div class="clearfix"> </div>
         </div>

      </div>
   </div>
