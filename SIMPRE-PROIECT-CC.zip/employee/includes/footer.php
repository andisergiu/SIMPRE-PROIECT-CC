 <div class="container-fluid"><!-- -->
                     <div class="footer">
                        <p>Autor: Sergiu Costan @ 2024</p>
                     </div>
                  </div>